<?php
require '../includes/functions.php';
requireAdmin();
require '../config/db.php';

$totalMilk = getTotalMilk($pdo);

$stmt = $pdo->query("SELECT COUNT(*) as approved FROM users WHERE role='customer' AND status='approved'");
$approvedCount = $stmt->fetchColumn();

$stmt = $pdo->query("SELECT COUNT(*) as pending FROM users WHERE role='customer' AND status='pending'");
$pendingCount = $stmt->fetchColumn();
?>
<?php include '../includes/header.php'; ?>
<h2>Admin Dashboard</h2>
<div class="row g-4 mb-5">
    <div class="col-md-4">
        <div class="card stat-card h-100 text-center">
            <div class="card-body">
                <i class="fas fa-tint fa-4x text-primary mb-3 milk-icon"></i>
                <h1 class="total-milk"><?= number_format($totalMilk, 2) ?> L</h1>
                <p class="fs-5 fw-semibold">Tomorrow's Demand</p>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card stat-card h-100 text-center">
            <div class="card-body">
                <i class="fas fa-user-check fa-4x text-success mb-3 milk-icon"></i>
                <h3 class="display-4"><?= $approvedCount ?></h3>
                <p class="fs-5 fw-semibold">Active Customers</p>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card stat-card h-100 text-center">
            <div class="card-body">
                <i class="fas fa-user-clock fa-4x text-warning mb-3 milk-icon"></i>
                <h3 class="display-4"><?= $pendingCount ?></h3>
                <p class="fs-5 fw-semibold">Pending Approval</p>
            </div>
        </div>
    </div>
</div>
<a href="approve.php" class="btn btn-primary">Manage Customers</a>
<a href="../logout.php" class="btn btn-secondary">Logout</a>
<?php include '../includes/footer.php'; ?>

