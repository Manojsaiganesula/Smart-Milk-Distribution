<?php
require '../includes/functions.php';
require '../config/db.php';

$error = '';
if ($_POST) {
    if (login($pdo, $_POST['email'], $_POST['password'])) {
        if ($_SESSION['role'] === 'admin') {
            header('Location: dashboard.php');
            exit;
        } else {
            $error = 'Admin access only.';
            session_destroy();
        }
    } else {
        $error = 'Invalid credentials.';
    }
}
?>
<?php include '../includes/header.php'; ?>
<h2>Admin Login</h2>
<?php if ($error): ?>
<div class="alert alert-danger"><?= $error ?></div>
<?php endif; ?>
<form method="POST">
    <div class="mb-3">
        <label>Email: admin@milk.com</label>
        <input type="email" name="email" class="form-control" required>
    </div>
    <div class="mb-3">
        <label>Password: admin123</label>
        <input type="password" name="password" class="form-control" required>
    </div>
    <button class="btn btn-primary">Login</button>
    <a href="../index.php" class="btn btn-secondary">Back</a>
</form>
<?php include '../includes/footer.php'; ?>

